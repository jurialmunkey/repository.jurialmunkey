from jurialmunkey.ftools import cached_property


class MDbListRatingMappingObject:
    rating_keys = {
        'tomatoes': 'rottentomatoes_rating',
        'tomatoesaudience': 'rottentomatoes_usermeter',
        'popcorn': 'rottentomatoes_usermeter',
        'metacritic': 'metacritic_rating'}

    rating_func = {
        'imdb': lambda v: int(v * 10),  # Convert out of /10 to 100%
        'metacriticuser': lambda v: int(v * 10),  # Convert out of /10 to 100%
        'letterboxd': lambda v: int(v * 20),  # Convert 5 stars to 100%
        'rogerebert': lambda v: int(v * 25),  # Convert 4 stars to 100%
        'myanimelist': lambda v: int(v * 10),  # Convert out of /10 to 100%
    }

    def __init__(self, meta):
        self.meta = meta

    @cached_property
    def name(self):
        return self.get_name()

    def get_name(self):
        try:
            return self.meta['source']
        except KeyError:
            return

    @cached_property
    def rating_key(self):
        return self.get_rating_key()

    def get_rating_key(self):
        try:
            return self.rating_keys[self.name]
        except KeyError:
            return f'{self.name}_rating'

    @cached_property
    def rating_value(self):
        return self.get_rating_value()

    def get_rating_value(self):
        try:
            rating = None
            rating = self.meta['value']
            return self.rating_func[self.name](rating)
        except (KeyError, TypeError):  # TypeError in case of null value with integer lambda
            return rating

    @cached_property
    def votes_key(self):
        return f'{self.name}_votes'

    @cached_property
    def votes_value(self):
        return self.get_votes_value()

    def get_votes_value(self):
        try:
            return self.meta['votes']
        except KeyError:
            return

    @cached_property
    def ratings(self):
        return {
            k: v for k, v in (
                (self.rating_key, self.rating_value),
                (self.votes_key, self.votes_value)
            ) if k and v is not None
        } if self.name else {}

    def items(self):
        return self.ratings.items()


class MDbListKeywordRatingMappingObject(MDbListRatingMappingObject):
    votes_key = None
    votes_value = None

    rating_keywords = {
        'certified-fresh': ('rottentomatoes_image', 'certified'),
        'fresh': ('rottentomatoes_image', 'fresh'),
        'rotten': ('rottentomatoes_image', 'rotten'),
        'certified-hot': ('rottentomatoes_usermeter_image', 'hot'),
        'metacritic-must-see': ('metacritic_image', 'mustsee'),
        'roger-ebert-thumbs-down': ('rogerebert_image', 'thumbsdown'),
    }

    @cached_property
    def name(self):
        return self.get_name()

    def get_name(self):
        try:
            return self.meta['name']
        except KeyError:
            return

    @cached_property
    def rating_key(self):
        return self.get_rating_key()

    def get_rating_key(self):
        try:
            return self.rating_keywords[self.name][0]
        except KeyError:
            return

    @cached_property
    def rating_value(self):
        return self.get_rating_value()

    def get_rating_value(self):
        try:
            return self.rating_keywords[self.name][1]
        except KeyError:
            return


class MDbListRatingMapping:
    def __init__(self, meta):
        self.meta = meta

    @cached_property
    def meta_ratings(self):
        return self.get_meta_ratings()

    def get_meta_ratings(self):
        try:
            return self.meta['ratings']
        except (KeyError, TypeError):
            return []

    @cached_property
    def meta_keywords(self):
        return self.get_meta_keywords()

    def get_meta_keywords(self):
        try:
            return self.meta['keywords']
        except (KeyError, TypeError):
            return []

    @cached_property
    def ratings(self):
        return self.get_ratings()

    def get_ratings(self):
        ratings = {
            k: v
            for i in self.meta_ratings
            for k, v in MDbListRatingMappingObject(i).items()
        }
        ratings['mdblist_rating'] = self.meta.get('score')

        ratings.update({
            k: v
            for d in self.meta_keywords
            for k, v in MDbListKeywordRatingMappingObject(d).items()
        })

        return ratings


class MDbListSeasonRatingMapping:

    season = None

    def __init__(self, meta):
        self.meta = meta

    @cached_property
    def meta_episode_ratings(self):
        return self.get_meta_episode_ratings()

    def get_meta_episode_ratings(self):
        try:
            return self.meta['episode_ratings']
        except (KeyError, TypeError):
            return {}

    @cached_property
    def meta_season(self):
        return self.get_meta_season()

    def get_meta_season(self):
        try:
            return next((d for d in self.meta_episode_ratings['seasons'] if int(d['season_number']) == int(self.season)))
        except (KeyError, TypeError, StopIteration):
            return {}

    @cached_property
    def ratings(self):
        return self.get_ratings()

    def get_ratings(self):
        ratings = {}
        ratings['imdb_rating'] = self.meta_season.get('avg')  # MDbList episode_ratings return IMDb scores
        return ratings


class MDbListEpisodeRatingMapping(MDbListSeasonRatingMapping):

    episode = None

    @cached_property
    def meta_episode(self):
        return self.get_meta_episode()

    def get_meta_episode(self):
        try:
            return next((d for d in self.meta_season['episodes'] if int(d['episode_number']) == int(self.episode)))
        except (KeyError, TypeError, StopIteration):
            return {}

    @cached_property
    def ratings(self):
        return self.get_ratings()

    def get_ratings(self):
        ratings = {}
        ratings['imdb_rating'] = self.meta_episode.get('rating')  # MDbList episode_ratings return IMDb scores
        ratings['imdb_votes'] = self.meta_episode.get('votes')  # MDbList episode_ratings return IMDb votes
        return ratings
