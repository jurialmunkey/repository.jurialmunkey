from tmdbhelper.lib.items.directories.mapper_basic import ItemMapper, NullItemMapper
from jurialmunkey.ftools import cached_property
from tmdbhelper.lib.addon.plugin import get_localized
from tmdbhelper_sync_trakt.settings import TraktSettings
from tmdbhelper_sync_trakt.directories.artwork import ADDONPATH
from tmdbhelper.lib.addon.consts import RUNSCRIPT
from contextlib import suppress


class StaticItemMapper(ItemMapper):
    @cached_property
    def label(self):
        return self.list_name

    @cached_property
    def list_slug(self):
        return self.get_list_slug()

    def get_list_slug(self):
        with suppress(KeyError):
            return self.meta['list']['ids']['slug']

    @cached_property
    def user_slug(self):
        return self.get_user_slug()

    def get_user_slug(self):
        with suppress(KeyError):
            return self.meta['list']['user']['ids']['slug']

    @cached_property
    def list_name(self):
        return self.get_list_name()

    def get_list_name(self):
        with suppress(KeyError):
            return self.meta['list'].get('name') or ''

    @cached_property
    def user_name(self):
        return self.get_user_name()

    def get_user_name(self):
        with suppress(KeyError):
            return self.meta['list']['user'].get('name') or self.user_slug or ''

    @cached_property
    def list_description(self):
        return self.get_list_description()

    def get_list_description(self):
        with suppress(KeyError):
            return self.meta['list'].get('description')

    def get_params(self):
        params = {
            'info': 'trakt_userlist',
            'tmdb_type': 'both',
            'list_name': self.list_name,
            'list_slug': self.list_slug,
            'user_slug': self.user_slug,
            'plugin_category': self.list_name,
        }
        return params

    def get_infolabels(self):
        infolabels = {
            'plot': self.list_description,
            'studio': [self.user_name],
        }
        return infolabels

    def get_infoproperties(self):
        infoproperties = {
            k: v for k, v in self.meta['list'].items()
            if v and type(v) not in [list, dict]
        }
        infoproperties.update({'is_sortable': 'True'})
        infoproperties['sortby_info'] = 'trakt_sortby'
        return infoproperties

    def get_unique_ids(self):
        unique_ids = {
            'slug': self.list_slug,
            'user': self.user_slug,
        }
        return unique_ids

    def get_sort_context_menu(self):
        return [
            (
                get_localized(32309),
                RUNSCRIPT.format('sort_list,{}'.format(','.join(f'{k}={v}' for k, v in self.params.items())))
            ),
        ]

    def get_context_menu(self):
        return self.get_sort_context_menu() + [
            (
                get_localized(20444),
                RUNSCRIPT.format('user_list={list_slug},user_slug={user_slug}'.format(**self.params))
            ),
        ]


class StaticOfficialItemMapper(StaticItemMapper):
    user_slug = 'official'
    user_name = 'Trakt'

    @cached_property
    def list_slug(self):
        return self.get_list_slug()

    def get_list_slug(self):
        with suppress(KeyError):
            return self.meta['list']['ids']['trakt']

    def get_context_menu(self):
        return self.get_sort_context_menu()


class StaticLikedItemMapper(StaticItemMapper):
    def get_context_menu(self):
        context_menu = super().get_context_menu()
        context_menu = context_menu + [
            (
                get_localized(32319),
                RUNSCRIPT.format('like_list={list_slug},user_slug={user_slug},delete'.format(**self.params))
            )
        ]
        return context_menu


class StaticUnLikedItemMapper(StaticItemMapper):
    def get_context_menu(self):
        context_menu = super().get_context_menu()
        context_menu = context_menu + [
            (
                get_localized(32315),
                RUNSCRIPT.format('like_list={list_slug},user_slug={user_slug}'.format(**self.params))
            )
        ]
        return context_menu


class StaticOwnedItemMapper(StaticItemMapper):
    def get_context_menu(self):
        context_menu = super().get_context_menu()
        context_menu = context_menu + [
            (
                get_localized(118),
                RUNSCRIPT.format('rename_list={list_slug}'.format(**self.params))
            ),
            (
                get_localized(117),
                RUNSCRIPT.format('delete_list={list_slug}'.format(**self.params))
            )
        ]
        return context_menu


class StaticOfficialLikedItemMapper(StaticLikedItemMapper, StaticOfficialItemMapper):
    pass


class StaticOfficialUnLikedItemMapper(StaticUnLikedItemMapper, StaticOfficialItemMapper):
    pass


class StaticOfficialOwnedItemMapper(StaticOwnedItemMapper, StaticOfficialItemMapper):
    pass


class StaticItemMapperFactoryHelper:
    def __init__(self, meta):
        self.meta = meta

    @cached_property
    def user_slug(self):
        return self.meta['list'].get('user', {}).get('ids', {}).get('slug')

    @cached_property
    def list_slug(self):
        return self.meta['list'].get('ids', {}).get('slug')

    @cached_property
    def privacy(self):
        return self.meta['list'].get('privacy')

    @cached_property
    def is_official(self):
        return self.meta['list']['type'] == 'official'

    @cached_property
    def is_available(self):
        return self.get_is_available()

    def get_is_available(self):
        if not self.user_slug:
            return False
        if not self.list_slug:
            return False
        if self.privacy == 'public':
            return True
        if self.privacy == 'private':
            return self.meta.get('user_profile_slug') == self.user_slug
        return True


class StaticItemMapperFactory:
    item_mapper_class = StaticItemMapper
    official_item_mapper_class = StaticOfficialItemMapper

    def __new__(cls, meta, add_infoproperties=None):
        helper = StaticItemMapperFactoryHelper(meta)
        if helper.is_official:
            return cls.official_item_mapper_class(meta, add_infoproperties)
        if helper.is_available:
            return cls.item_mapper_class(meta, add_infoproperties)
        return NullItemMapper()


class StaticLikedItemMapperFactory(StaticItemMapperFactory):
    item_mapper_class = StaticLikedItemMapper
    official_item_mapper_class = StaticOfficialLikedItemMapper


class StaticUnLikedItemMapperFactory(StaticItemMapperFactory):
    item_mapper_class = StaticUnLikedItemMapper
    official_item_mapper_class = StaticOfficialUnLikedItemMapper


class StaticOwnedItemMapperFactory(StaticItemMapperFactory):
    item_mapper_class = StaticOwnedItemMapper
    official_item_mapper_class = StaticOfficialOwnedItemMapper


class StaticGenresItemMapper(ItemMapper):

    def __init__(self, *args, tmdb_type, **kwargs):
        super().__init__(*args, **kwargs)
        self.tmdb_type = tmdb_type

    @cached_property
    def label(self):
        return self.meta['name']

    @cached_property
    def slug(self):
        return self.meta['slug']

    @cached_property
    def icon_path(self):
        return TraktSettings().genre_icon_location

    @cached_property
    def custom_icon(self):
        return self.get_custom_icon()

    def get_custom_icon(self):
        import xbmcvfs
        custom_icon = xbmcvfs.validatePath(xbmcvfs.translatePath(f'{self.icon_path}/{self.slug}.png'))
        custom_icon = custom_icon if custom_icon and xbmcvfs.exists(custom_icon) else None
        return custom_icon

    @cached_property
    def icon(self):
        return self.get_icon()

    def get_icon(self):
        icon = self.custom_icon if self.icon_path else None
        icon = icon or f'{ADDONPATH}/resources/icons/trakt/genres.png'
        return icon

    def get_art(self):
        return {'icon': self.icon}

    def get_unique_ids(self):
        return {'slug': self.slug}

    def get_params(self):
        return {
            'info': 'trakt_genre',
            'genre': self.slug,
            'tmdb_type': self.tmdb_type,
        }
