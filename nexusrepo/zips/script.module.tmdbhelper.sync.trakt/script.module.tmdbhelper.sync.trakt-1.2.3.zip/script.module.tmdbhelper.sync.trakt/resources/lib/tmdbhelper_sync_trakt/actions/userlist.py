from tmdbhelper_sync_trakt.actions.service import ItemAction
from tmdbhelper.lib.addon.plugin import get_infolabel, get_localized
from tmdbhelper.lib.addon.dialog import busy_decorator
from jurialmunkey.ftools import cached_property
from xbmcgui import Dialog


class ItemUserList(ItemAction):
    preconfigured = True
    sync_url = 'items'

    @cached_property
    def userlist(self):
        return self.get_userlist()

    @cached_property
    def userlist_slug(self):
        return self.get_userlist_slug()

    @property
    def userlist_user(self):
        return self.get_userlist_user()

    """
    methods
    """

    def add_list(self):
        """ Create a new Trakt list and returns tuple of list and user slug """
        name = Dialog().input(get_localized(32356))
        if not name:
            return
        response = self.trakt_api.post_response('users/me/lists', postdata={'name': name})
        if not response or not response.json():
            return
        return (
            response.json().get('ids', {}).get('slug'),
            response.json().get('user', {}).get('ids', {}).get('slug'))

    def add_to_library(self, tmdb_type, tmdb_id, list_user_slug_tuple=None, confirm=True):
        """ Add item to library
        Pass optional slug tuple (list, user) to check if in monitored lists
        """

        from tmdbhelper.lib.update.monitor import MonitorUserLists
        monitor = MonitorUserLists()
        monitor.registry = self.syncdata.registry
        if list_user_slug_tuple and not monitor.is_monitored(*list_user_slug_tuple):
            return

        if confirm and not Dialog().yesno(get_localized(20444), get_localized(32362)):
            return

        from tmdbhelper.lib.script.method.library import add_to_library
        add_to_library(tmdb_type, tmdb_id=tmdb_id)

    """
    overrides
    """

    def get_remove(self):
        return (get_infolabel("ListItem.Property(param.info)") == 'trakt_userlist'
                and get_infolabel("ListItem.Property(param.owner)") == 'true')

    def get_name(self):
        return get_localized(32355) if self.remove else get_localized(32298)

    @cached_property
    def users_lists(self):
        return self.get_users_lists()

    @busy_decorator
    def get_users_lists(self):
        from tmdbhelper_sync_trakt.directories.lists_static import ListTraktStaticOwned
        container = ListTraktStaticOwned(-1, '')
        container.trakt_api = self.trakt_api
        users_lists = container.get_items(tmdb_type='both') or []
        users_lists.append({'label': get_localized(32299)})
        return users_lists

    @cached_property
    def users_lists_choices(self):
        return self.get_users_lists_choices()

    def get_users_lists_choices(self):
        return [i.get('label') for i in self.users_lists]

    def get_userlist(self):
        """ Get an existing Trakt list and returns tuple of list and user slug """
        if self.remove:
            return (
                get_infolabel("ListItem.Property(param.list_slug)"),
                get_infolabel("ListItem.Property(param.user_slug)"))
        x = Dialog().contextmenu(self.users_lists_choices)
        if x == -1:
            return
        if self.users_lists[x].get('label') == get_localized(32299):
            return self.add_list()
        return (
            self.users_lists[x].get('params', {}).get('list_slug'),
            self.users_lists[x].get('params', {}).get('user_slug'))

    def get_userlist_slug(self):
        if not self.userlist:
            return
        return self.userlist[0]

    def get_userlist_user(self):
        if not self.userlist:
            return
        return self.userlist[1]

    def get_post_response_args(self):
        return ('users', self.userlist_user, 'lists', self.userlist_slug, self.method, )

    def get_sync_response(self):
        if not self.userlist:
            return
        return super().get_sync_response()

    def sync(self):
        """ Entry point """
        if self.is_successful_sync:
            self.add_to_library(self.tmdb_type, self.tmdb_id, list_user_slug_tuple=(self.userlist_slug, self.userlist_user, ))
        self.display_dialog()
        self.refresh_containers()
