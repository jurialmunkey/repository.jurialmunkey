# Module: default
# Author: jurialmunkey
# License: GPL v.3 https://www.gnu.org/copyleft/gpl.html
from resources.lib.script.router import recache_image

if __name__ == '__main__':
    recache_image('listitem.blurimage')
