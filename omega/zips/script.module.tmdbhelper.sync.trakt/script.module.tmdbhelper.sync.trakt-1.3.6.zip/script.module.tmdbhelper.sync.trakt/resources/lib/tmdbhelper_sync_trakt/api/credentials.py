from tmdbhelper.lib.api.api_keys.tokenhandler import TokenHandler
from tmdbhelper_sync_trakt.settings import TraktSettings


class TraktTokenHandler(TokenHandler):
    def __init__(self):
        TraktSettings().migrate_credentials()
        super().__init__('token', store_as='setting')

    def _get_setting(self, name, *args):
        # Existing Kodi Addon handles can retain settings loaded before a token refresh.
        return TraktSettings().addon.getSetting(name)

    def _set_setting(self, name, value, *args):
        TraktSettings().migrate_setting(name, value)
